(function(this)

  -- 账户查询导航界面
      -- NAC0001.xhtml
          -- NAC0001.xhtml --> (点击明细，进入) NAC0002.xhtml
          -- NAC0001.xhtml--> (点击详情跳转到定期存款）
          -- NAC0001.xhtml --> (点击设置快速查询卡) TAC3A01.xhtml

    --下一页
    function btnonclick()
       local next_channelId = "test_channel";
       local next_trancode = "TEST0001";
       local post_body = {id=next_channelId,tranCode=next_trancode,};
       ert.channel:next_page(next_channelId, next_trancode, post_body);
      --cmm_unit_fun.skip_lib:refresh("display_account","account_query","showcard_ac0003.html");
    end;

end)(ert.channel:get_page("test_channel","TEST0001"));
