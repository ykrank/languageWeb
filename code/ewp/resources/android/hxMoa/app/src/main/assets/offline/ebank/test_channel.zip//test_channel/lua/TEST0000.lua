(function(this)
    --下一页
    --window:alert("测试");
    function btnonclick()
       --window:alert("12324234234");
       --testfun();
       local next_channelId = "test_channel";
       local next_trancode = "TEST0001";
       local account = ert.dom:get_property_by_name("account","value");
       --local account = ert("#account"):val();
       --local account = "123";
       --window:alert(ebank_public.format_lib:public_header("123"));

       window:alert(#ebank_public);
       local post_body = {id=next_channelId,tranCode=next_trancode,account=account};
       ert.channel:next_page(next_channelId, next_trancode, post_body);
    end;


        function startTradingPwdEncrypt()
          accountaccount = ert("#pwd"):val();
          ert("#account"):attr("value",accountaccount);
          local passObj = document:getElementsByName("pwd");
          local value = passObj[1]:getPropertyByName("value");
          window:alert(value);
        end;



      function startTradingPwdEncrypt1()
          accountaccount = ert("#pwd1"):val();
          ert("#account"):attr("value",accountaccount);
          local passObj = document:getElementsByName("pwd1");
          local value = passObj[1]:getPropertyByName("value");
          window:alert(value);
        end;

      function  startTradingPwdEncrypt2(  )
        accountaccount = ert("#pwd"):val();
        ert("#account"):attr("value",accountaccount);
      end

      function turn_erl()
          local passObj = document:getElementsByName("pwd1");
          local value = passObj[1]:getPropertyByName("value");

          tmp_cha_id = input_id[1]:getPropertyByName("value");
          tmp_trancode = input_code[1]:getPropertyByName("value");

          ert.channel:first_page(tmp_cha_id, tmp_trancode, {id=tmp_cha_id,tranCode=tmp_trancode,Pwd=value});

      end

end)(ert.channel:get_page("test_channel","TEST0001"));
