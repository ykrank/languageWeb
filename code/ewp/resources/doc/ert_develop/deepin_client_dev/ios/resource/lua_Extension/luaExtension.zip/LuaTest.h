//
//  LuaTest.h
//  APP
//
//  Created by Yu Cheng on 12-11-13.
//  Copyright (c) 2012年 RYTong. All rights reserved.
//

#import "LuaObject.h"

@interface LuaTest : LuaObject

@end
